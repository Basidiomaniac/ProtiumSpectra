rm(list=ls()) 
setwd("C:/Users/Jason/Dropbox/MY_RESEARCH(original)/Project_Metabolites/NIR")
#setwd("C:/Users/")

############################################################
#***********************************************************
##           PLSR and PLS-DA (cf "Notes_Jason")           ##
#***********************************************************
############################################################
## These are the analyses performed in Kothari et al. (2022) Methods in Ecol. and Evol.
## https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13958

#install.packages("prospectr")
#install.packages("mixOmics")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")
#BiocManager::install("mixOmics")

library(pls)       # PLSR and PLS-DA
library(mixOmics)  # PLSR and PLS-DA
library(ggplot2)   # graphics
library(viridis)   # for color scales in ggplot
library(vegan)     # permanova
library(forecast)  # data normalization
library(tidyverse) # for data manipulation
library(prospectr) # derivative transformation
library(randomForest) # random forest wavelength selection

#######################
# Simulate data
#######################

n <- 60            # individuals
p <- 100           # wavelengths (100 λ)

# X matrix = reflectances (random here but realistic)
X <- matrix(runif(n * p, 0.2, 0.7), nrow = n, ncol = p)
colnames(X) <- paste0("λ", 1:p)

# Trait to predict (partly linked to X)
trait <- rowMeans(X[, 20:40]) + rnorm(n, 0, 0.05)

# Species (3 groups)
species <- factor(rep(c("EspA", "EspB", "EspC"), each = n / 3))

################################################################
# 1. PLSR (Partial Least Squares Regression): predict a trait
################################################################
## => Objective of PLSR: "Which spectra predict trait Y?"
## Here we find combinations of X that best explain Y variance

# Build the PLSR model with cross-validation
plsr_model <- plsr(trait ~ X, ncomp = 20, validation = "CV")
summary(plsr_model)
## CV = Cross-Validation
## RMSEP = Root Mean Square Error of Prediction
## gives an estimate of the error you'd make predicting new data
## depending on how many PLS components you use

# Plot PLSR scores with ggplot
scores <- scores(plsr_model)[, 1:2]
colnames(scores) <- c("Comp1", "Comp2")

# Visualize TRAITS
scores_df <- data.frame(scores, trait = trait)

ggplot(scores_df, aes(x = Comp1, y = Comp2, color = trait)) +
  geom_point(size = 3, alpha = 0.8) +
  scale_color_viridis(option = "C", direction = -1, name = "Trait value") +
  theme_minimal() +
  labs(title = "PLSR Projection of individuals",
       subtitle = "Colored by trait value",
       x = "PLS Component 1", y = "PLS Component 2")

# Visualize SPECIES
scores_df <- data.frame(scores, species = species)

# Compute centroids by species
centroids <- aggregate(cbind(Comp1, Comp2) ~ species, data = scores_df, FUN = mean)

ggplot(scores_df, aes(x = Comp1, y = Comp2, color = species)) +
  geom_point(size = 3, alpha = 0.7) +
  geom_point(data = centroids, aes(x = Comp1, y = Comp2),
             shape = 4, size = 5, stroke = 2, color = "black") +
  geom_text(data = centroids, aes(label = species),
            vjust = -1, color = "black", fontface = "bold") +
  theme_minimal() +
  labs(title = "PLSR Projection colored by species",
       x = "PLS Component 1", y = "PLS Component 2", color = "Species")

# Visualize TRAITS and SPECIES
scores <- scores(plsr_model)[, 1:2]
colnames(scores) <- c("Comp1", "Comp2")

scores_df <- data.frame(scores, trait = trait, species = species)

centroids <- aggregate(cbind(Comp1, Comp2) ~ species, data = scores_df, FUN = mean)

# Direction of the trait (arrow)
trait_model <- lm(trait ~ Comp1 + Comp2, data = scores_df)
coeffs <- coef(trait_model)[-1]
arrow <- data.frame(x = 0, y = 0,
                    xend = coeffs["Comp1"] * 5,
                    yend = coeffs["Comp2"] * 5)

ggplot(scores_df, aes(x = Comp1, y = Comp2)) +
  geom_point(aes(color = trait, shape = species), size = 3, alpha = 0.9) +
  geom_point(data = centroids, aes(x = Comp1, y = Comp2),
             shape = 4, size = 5, stroke = 2, color = "black") +
  geom_text(data = centroids, aes(x = Comp1, y = Comp2, label = species),
            vjust = -1, color = "black", fontface = "bold") +
  geom_segment(data = arrow, aes(x = x, y = y, xend = xend, yend = yend),
               arrow = arrow(length = unit(0.3, "cm")), color = "black", linewidth = 1) +
  annotate("text", x = coeffs["Comp1"] * 5.5, y = coeffs["Comp2"] * 5.5,
           label = "↑ Trait", fontface = "italic", hjust = 0.5) +
  scale_color_viridis(option = "C", direction = -1, name = "Trait value") +
  scale_shape_manual(values = c(16, 17, 15)) +
  theme_minimal() +
  labs(title = "PLSR: individuals colored by trait",
       subtitle = "Shape = species, arrow = trait direction, cross = centroid",
       x = "PLS Component 1", y = "PLS Component 2", shape = "Species") +
  stat_ellipse(type = "norm", level = 0.68, aes(group = species), linetype = "solid")

# RMSEP plot
plot(RMSEP(plsr_model), main = "RMSEP - PLSR")

# Find optimal number of components
ncomp_opt <- which.min(RMSEP(plsr_model)$val[1,1,])
cat("Optimal number of components:", ncomp_opt, "\n")

# Predict with optimal components
Y_pred <- predict(plsr_model, ncomp = ncomp_opt)

plot(Y_pred~trait); abline(lm(Y_pred~trait), col="blue")
RsquareAdj(rda(Y_pred~trait))

# Loadings of spectral variables
## Loadings show how much each wavelength (X) contributes to each PLS component.
## High absolute value = this wavelength weighs heavily in the component
load1 <- loadings(plsr_model)[,1]

# Wavelength range (e.g., 1000–2500 nm)
wavelengths <- seq(1000, 2500, length.out = ncol(X))

plot(wavelengths, abs(load1), type = "h", lwd = 1,
     main = "Loadings of wavelengths (component 1)",
     xlab = "Wavelength (nm)", ylab = "Loading")

# Regression coefficients
## Coefficients are used to predict Y.
## They indicate which wavelengths influence the prediction the most
coefs <- as.vector(coef(plsr_model, ncomp = ncomp_opt))
plot(wavelengths, coefs, type = "h", lwd = 1,
     main = paste("PLSR regression coefficients (", ncomp_opt, " components)"),
     xlab = "Wavelength (nm)", ylab = "Coefficient")

#####################################
# 2. PLS-DA: discriminate species
#####################################
## => Objective: "Which wavelengths discriminate species?"
## Here, Y (species) is predicted from X (spectra)

## Data example (please don't share this dataset)
data=as.data.frame(read.csv("extracts_01.csv",h=T))
head(data) ; dim(data)

X <- data %>%
  dplyr::select(Sample, Wavelength, Reflectance) %>%
  pivot_wider(names_from = Wavelength, values_from = Reflectance) %>%
  arrange(Sample) %>%
  distinct()

y <- data %>%
  dplyr::select(Sample, Species) %>%
  distinct() %>%
  arrange(Sample) %>%
  pull(Species) %>%
  as.factor()

spectre <- X %>%
  dplyr::select(-Sample) %>%
  as.matrix()

## Derivative transformation => often improve separation (to compare with and without)
spectre <- savitzkyGolay(spectre, m = 1, p = 2, w = 11)  # first derivative
head(spectre[,1:10]);dim(spectre)

# Trim to keep wavelengths > 300 while avoiding ranges with water-related noise
wl <- as.numeric(colnames(spectre))
w  <- wl ## default (all wavelength kept)

## if excluding wavelength ranges with potential water noise:
keep <- (
  (wl >= 300 & wl <= 1350) |
  (wl >= 1450 & wl <= 1850) |
  (wl >= 1950 & wl <= 2400)
)

# Get indices of columns to keep
w <- which(keep) ; length(w)

spectre2 = spectre[,w]

# Box-Cox normalization and z-score standardization
spectre3 = spectre2+abs(min(spectre2))+0.000001
for(i in 1:ncol(spectre3)) {
  lambda1 <- BoxCox.lambda(spectre3[,i],method = "loglik", lower = -3, upper = 3) 
  spectre3[,i] <- BoxCox(spectre3[,i], lambda=lambda1)
}
for(i in 1:ncol(spectre3)) {
  spectre3[,i] = decostand(spectre3[,i],"standardize")
}
head(spectre3[,1:5])

# PLS-DA
plsda_model <- plsda(spectre3, y, ncomp = 3)
plotIndiv(plsda_model, comp = c(1, 2), group = y, legend = TRUE,
          title = "PLS-DA on leaf spectra by species")

# Keep most discriminant wavelengths
vip_scores <- vip(plsda_model)
top_vars <- which(vip_scores[,1] > 1)
spectre4 <- spectre3[, top_vars]
head(spectre4[,1:5])

# Random Forest importance
rf_model <- randomForest(x = spectre4, y = y, ntree = 100)
importance_rf <- importance(rf_model)

ord = rev(order(as.numeric(importance_rf[,1])))[1:50] ; ord
spectre5 <- spectre4[,ord]
head(spectre5[,1:5]) ; dim(spectre5)

# Re-train PLS-DA
plsda_model <- plsda(spectre5, y, ncomp = 2)

# Visualization with centroids
scores <- plsda_model$variates$X[, 1:2]
colnames(scores) <- c("Comp1", "Comp2")
scores_df <- data.frame(scores, species = y)
centroids <- aggregate(cbind(Comp1, Comp2) ~ species, data = scores_df, FUN = mean)

ggplot(scores_df, aes(x = Comp1, y = Comp2, color = species)) +
  geom_point(size = 3, alpha = 0.7) +
  geom_point(data = centroids, aes(x = Comp1, y = Comp2), 
             shape = 4, size = 5, stroke = 2, color = "black") +
  geom_text(data = centroids, aes(label = species), 
            vjust = -1, color = "black", fontface = "bold") +
  theme_minimal() +
  labs(title = "PLS-DA: individuals and centroids by species",
       x = "PLS Component 1", y = "PLS Component 2") +
  stat_ellipse(type = "norm", level = 0.68)

# PERMANOVA test: do spectra significantly separate species?
adonis = adonis2(plsda_model$variates$X[, 1:2] ~ y, method = "euclidean")
adonis

# Cross-validation classification error
perf.plsda <- perf(plsda_model, validation = "Mfold", folds = 5,
                   progressBar = TRUE, nrepeat = 50)
plot(perf.plsda)
summary(perf.plsda)
